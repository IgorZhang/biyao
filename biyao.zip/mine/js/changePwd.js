app.controller('changePwdCtrl', function ($scope, $css) {
    $css.removeAll();
    $css.add('../mine/css/changePwd.css')
});
