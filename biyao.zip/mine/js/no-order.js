app.controller('noOrderCtrl', function ($scope, $css) {
    $css.removeAll();
    $css.add('../mine/css/no-order.css');
})
