app.controller('orderInfoCtrl', function ($scope, $css) {
    $css.removeAll();
    $css.add('../mine/css/orderInfo.css');
})
