app.controller("modifiedCtrl", function ($scope,$css) {
    $css.removeAll();
    $css.add("../mine/css/modified.css");
});
