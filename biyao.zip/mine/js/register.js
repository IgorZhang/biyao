app.controller('registerCtrl', function ($scope, $css) {
    $css.removeAll();
    $css.add('../mine/css/register.css')
})
