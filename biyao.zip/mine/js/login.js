app.controller('loginCtrl', function ($scope, $css) {
    $css.removeAll();
    $css.add('../mine/css/login.css')


});
