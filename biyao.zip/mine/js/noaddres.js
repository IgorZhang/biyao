app.controller("addresCtrl", function ($scope,$css) {
  $css.removeAll();
  $css.add('../mine/css/noaddres.css')

});
