app.controller("spxq-yjCtrl", function ($scope, $css) {
  $css.removeAll();
  $css.add('spxq/css/spxq-yj.css');
  $css.add('libs/reset.css');
});
